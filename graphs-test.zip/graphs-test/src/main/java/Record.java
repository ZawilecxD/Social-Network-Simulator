/**
 * Created by Murzynas on 2016-12-15.
 */
public class Record {
    private int from;
    private int to;
    private double sentiment1;
    private double sentiment2;

    public Record(int from, int to, double s1, double s2) {
        this.setFrom(from);
        this.setTo(to);
        this.setSentiment1(s1);
        this.setSentiment2(s2);
    }

    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public int getTo() {
        return to;
    }

    public void setTo(int to) {
        this.to = to;
    }

    public double getSentiment1() {
        return sentiment1;
    }

    public void setSentiment1(double sentiment1) {
        this.sentiment1 = sentiment1;
    }

    public double getSentiment2() {
        return sentiment2;
    }

    public void setSentiment2(double sentiment2) {
        this.sentiment2 = sentiment2;
    }
}
