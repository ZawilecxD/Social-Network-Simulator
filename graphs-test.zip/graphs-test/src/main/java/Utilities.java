import org.graphstream.algorithm.BetweennessCentrality;
import org.graphstream.algorithm.PageRank;
import org.graphstream.algorithm.generator.DorogovtsevMendesGenerator;
import org.graphstream.algorithm.generator.Generator;
import org.graphstream.algorithm.measure.Modularity;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.MultiGraph;
import org.graphstream.graph.implementations.SingleGraph;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Murzynas on 2016-12-19.
 */
public class Utilities {
    public Utilities() {
    }

    public BigInteger factorial(int n ){
        if (n < 0) {
            return BigInteger.ZERO;
        } else if (n==0){
            return BigInteger.ONE;
        } else {
            return BigInteger.valueOf(n).multiply(factorial(n-1));
        }
    }

    private static String createEdgeId(int from, int to) {
        return from+"-"+to;
    }

    public Graph loadGraph(int nodesCount) {
        Graph graph = new MultiGraph("Graph");
        graph.setStrict(false);
        graph.setAutoCreate( true );
        Edge e = null;
        String id = "-1";
//        graph.display();
        for(Record r : readCSV()) {
            id=createEdgeId(r.getFrom(), r.getTo());
            e = graph.addEdge(id, r.getFrom()+"", r.getTo()+"");
            if(e == null) {
                e = graph.getEdge(id);
                Double currWeight = e.getAttribute("weight");
                e.setAttribute("weight", currWeight+Double.valueOf(r.getSentiment1()));
            } else {
                e.setAttribute("weight", r.getSentiment1());
            }
            try {
//                Thread.sleep(200);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }


//        return graph;
//        Graph graph = new SingleGraph("test");
//        graph.addAttribute("ui.antialias", true);
//        graph.addAttribute("ui.stylesheet",
//                "node {fill-color: red; size-mode: dyn-size;} edge {fill-color:grey;}");
////        graph.display();
//
//        DorogovtsevMendesGenerator generator = new DorogovtsevMendesGenerator();
//        generator.setDirectedEdges(true, true);
//        generator.addSink(graph);
//
//        PageRank pageRank = new PageRank();
//        pageRank.init(graph);
//
//        generator.begin();
//        while (graph.getNodeCount() < nodesCount) {
//            generator.nextEvents();
//            for (Node node : graph) {
//                double rank = pageRank.getRank(node);
//                node.addAttribute("ui.size",
//                        5 + Math.sqrt(graph.getNodeCount() * rank * 20));
//                node.addAttribute("ui.label", String.format("%.2f%%", rank * 100));
//            }
////            Thread.sleep(1000);
//        }
//
//        Modularity mod = new Modularity();
//        mod.init(graph);
//        mod.compute();
//        System.out.println("Modularity: "+mod.getMeasure());
        return graph;
    }

    public List<Double> calculateBetweenessCentrality(Graph graph) {
        ArrayList<Double> results = new ArrayList<>();
        BetweennessCentrality bcb = new BetweennessCentrality();
        bcb.init(graph);
        bcb.computeEdgeCentrality(true);
        bcb.compute();
        for(Node n : graph.getNodeSet()) {
            results.add(n.getAttribute("Cb"));
        }
        return results;
    }

    public List<Record> readCSV() {
        ArrayList<Record> records = new ArrayList<>();
        String csvFile = "D:\\Projekty\\csv\\2008_01_01_to_2008_01_08.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ";";

        try {
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {
                String[] record = line.split(cvsSplitBy);

                records.add(new Record(
                        Integer.parseInt(record[0]),
                        Integer.parseInt(record[1]),
                        Double.parseDouble(record[2]),
                        Double.parseDouble(record[3])
                ));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return records;
        }
    }
}
