package csv;

import java.io.FileWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;

/**
 * Created by Murzynas on 2016-12-25.
 */
public class MainCsvClass {

    private static String selectUsersInteractionsForGivenTimeInterval =
            "select * from users_interactions where date between ? and ?";

    public static void main(String args[]) {
        String startDate =  args[0];
        String endDate =  args[1];
        Integer interval = 7;
        if(args.length > 2) {
            interval = Integer.valueOf(args[2]);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar currentCallendar = Calendar.getInstance();
        Calendar endCallendar = Calendar.getInstance();
        Date tempDate = null;
        System.out.println("Start date: "+startDate+"  EndDate: "+endDate);
        try {
            currentCallendar.setTime(sdf.parse(startDate));
            endCallendar.setTime(sdf.parse(endDate));
            while(currentCallendar.before(endCallendar)) {
                tempDate = new Date(currentCallendar.getTime().getTime());
                currentCallendar.add(Calendar.DATE, interval);
                System.out.println("Getting time interval stats for week from "+sdf.parse(tempDate.toString())+" to "+sdf.format(currentCallendar.getTime()));
                getUsersInteractionsForTimeInterval(
                        tempDate,
                        Date.valueOf(sdf.format(currentCallendar.getTime()))
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void getUsersInteractionsForTimeInterval(Date from, Date to) {
        PreparedStatement ps = null;
        String csvFile = CsvEditor.buildFilePath(from, to);
        Connection c = databaseConnection();
        try {
            FileWriter writer = new FileWriter(csvFile);
            ps = c.prepareStatement(selectUsersInteractionsForGivenTimeInterval);
            ps.setDate(1, from);
            ps.setDate(2, to);
            int fromId, toId = 0;
            double sentiment, sentiment2;
            Timestamp date = null;
            String type = null;
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                fromId = rs.getInt("source");
                toId = rs.getInt("target");
                sentiment = rs.getDouble("weight");
                sentiment2 = rs.getDouble("weight2");
                type = rs.getString("type");
                date = rs.getTimestamp("date");
                CsvEditor.writeLine(writer, Arrays.asList(
                        String.valueOf(fromId),
                        String.valueOf(toId),
                        String.valueOf(sentiment),
                        String.valueOf(sentiment2),
                        String.valueOf(date),
                        type
                        )
                );
            }
            writer.flush();
            writer.close();
        } catch(Exception e) {
            System.err.println("ERROR while processing data: "+from.toString()+" "+to.toString());
            e.printStackTrace();
        } finally {
            try {

                ps.close();
                c.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

    }

    public static Connection databaseConnection() {
        Connection c = null;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/salon24db",
                            "postgres", "");
            c.setAutoCommit(false);
            System.out.println("Opened database connection successfully");
            return c;
        } catch ( Exception e ) {
            e.printStackTrace();
            System.exit(0);
            return null;
        }
    }
}
