package no.gui;

import repast.simphony.runtime.*;

/**
 * Created by Murzynas on 2017-01-05.
 */
public class UserMain {

    public UserMain() {
    }

    public void start() {
        String[] args = new String[]{"D:\\Projekty\\toik\\graphs-test\\src\\main\\resources\\DataBaseAnalyzer.rs"};
        RepastMain.main(args);
    }

    public static void main(String[] args) {

        UserMain um = new UserMain();
        um.start();
    }
}
